
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `area_trabajos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `area_trabajos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `area_trabajos` WRITE;
/*!40000 ALTER TABLE `area_trabajos` DISABLE KEYS */;
INSERT INTO `area_trabajos` VALUES (1,'DACE',NULL,NULL),(2,'RRHH',NULL,NULL),(3,'AUDIO VISUAL',NULL,NULL),(4,'ACADÉMICA',NULL,NULL),(5,'CONSERJERÍA ESTUDIANTIL',NULL,NULL),(6,'DEPORTE',NULL,NULL),(7,'CULTURA Y RECREACIÓN',NULL,NULL),(8,'SERVICIO Y MANTENIMIENTO',NULL,NULL);
/*!40000 ALTER TABLE `area_trabajos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignacion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_prof` int(10) unsigned NOT NULL,
  `id_asignatura` int(10) unsigned NOT NULL,
  `id_seccion` int(10) unsigned NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignacion_id_prof_foreign` (`id_prof`),
  KEY `asignacion_id_asignatura_foreign` (`id_asignatura`),
  KEY `asignacion_id_seccion_foreign` (`id_seccion`),
  KEY `asignacion_id_periodo_foreign` (`id_periodo`),
  CONSTRAINT `asignacion_id_asignatura_foreign` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_id_prof_foreign` FOREIGN KEY (`id_prof`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_id_seccion_foreign` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignacion` WRITE;
/*!40000 ALTER TABLE `asignacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignacion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignacion_bloques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignacion_bloques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_asig` int(10) unsigned NOT NULL,
  `id_seccion` int(10) unsigned NOT NULL,
  `id_bloque` int(10) unsigned NOT NULL,
  `id_aula` int(10) unsigned NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `asignacion_bloques_id_asig_foreign` (`id_asig`),
  KEY `asignacion_bloques_id_seccion_foreign` (`id_seccion`),
  KEY `asignacion_bloques_id_bloque_foreign` (`id_bloque`),
  KEY `asignacion_bloques_id_aula_foreign` (`id_aula`),
  KEY `asignacion_bloques_id_periodo_foreign` (`id_periodo`),
  CONSTRAINT `asignacion_bloques_id_asig_foreign` FOREIGN KEY (`id_asig`) REFERENCES `asignaturas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_bloques_id_aula_foreign` FOREIGN KEY (`id_aula`) REFERENCES `aulas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_bloques_id_bloque_foreign` FOREIGN KEY (`id_bloque`) REFERENCES `bloques` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_bloques_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_bloques_id_seccion_foreign` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignacion_bloques` WRITE;
/*!40000 ALTER TABLE `asignacion_bloques` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignacion_bloques` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignacion_coordinador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignacion_coordinador` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_prof` int(10) unsigned NOT NULL,
  `id_seccion` int(10) unsigned NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignacion_coordinador_id_prof_foreign` (`id_prof`),
  KEY `asignacion_coordinador_id_seccion_foreign` (`id_seccion`),
  KEY `asignacion_coordinador_id_periodo_foreign` (`id_periodo`),
  CONSTRAINT `asignacion_coordinador_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_coordinador_id_prof_foreign` FOREIGN KEY (`id_prof`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asignacion_coordinador_id_seccion_foreign` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignacion_coordinador` WRITE;
/*!40000 ALTER TABLE `asignacion_coordinador` DISABLE KEYS */;
/*!40000 ALTER TABLE `asignacion_coordinador` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asignaturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asignaturas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asignatura` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_curso` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asignaturas_id_curso_foreign` (`id_curso`),
  CONSTRAINT `asignaturas_id_curso_foreign` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asignaturas` WRITE;
/*!40000 ALTER TABLE `asignaturas` DISABLE KEYS */;
INSERT INTO `asignaturas` VALUES (1,'Relación Lógica Matemática','RLM-EI',1,NULL,NULL),(2,'Comprensión Oral Escrita','COE-EI',1,NULL,NULL),(3,'Desarrollo Personal y Social','DPS-EI',1,NULL,NULL),(4,'Comprensión Personal Artística','CPA-EI',1,NULL,NULL),(5,'Expresión Corporal','EC-EI',1,NULL,NULL),(6,'Identidad y Autonomía del Desarrollo','IAD-EI',1,NULL,NULL),(7,'Inglés','I-EIO',1,NULL,NULL),(8,'Computación','C-EIO',1,NULL,NULL),(9,'Formación Cristiana','FC-EIO',1,NULL,NULL),(10,'Relación Lógica Matemática','RLM-1',2,NULL,NULL),(11,'Comprensión Oral Escrita','COE-1',2,NULL,NULL),(12,'Desarrollo Personal y Social','DPS-1',2,NULL,NULL),(13,'Comprensión Personal Artística','CPA-1',2,NULL,NULL),(14,'Expresión Corporal','EC-1',2,NULL,NULL),(15,'Identidad y Autonomía del Desarrollo','IAD-1',2,NULL,NULL),(16,'Inglés','I-1O',2,NULL,NULL),(17,'Computación','C-1O',2,NULL,NULL),(18,'Formación Cristiana','FC-1O',2,NULL,NULL),(19,'Matemática','M-2',3,NULL,NULL),(20,'Lenguaje y Literatura','LL-2',3,NULL,NULL),(21,'Entorno Natural y Social','ENS-2',3,NULL,NULL),(22,'Educación Estética','EE-2',3,NULL,NULL),(23,'Educación Física','EF-2',3,NULL,NULL),(24,'Inglés','I-2O',3,NULL,NULL),(25,'Computación','C-2O',3,NULL,NULL),(26,'Formación Cristiana','FC-2O',3,NULL,NULL),(27,'Valores Humanos','VH-2O',3,NULL,NULL),(28,'Matemática','M-3',4,NULL,NULL),(29,'Lenguaje y Literatura','LL-3',4,NULL,NULL),(30,'Entorno Natural y Social','ENS-3',4,NULL,NULL),(31,'Educación Estética','EE-3',4,NULL,NULL),(32,'Educación Física','EF-3',4,NULL,NULL),(33,'Inglés','I-3O',4,NULL,NULL),(34,'Computación','C-3O',4,NULL,NULL),(35,'Formación Cristiana','FC-3O',4,NULL,NULL),(36,'Valores Humanos','VH-3O',4,NULL,NULL),(37,'Matemática','M-4',5,NULL,NULL),(38,'Lenguaje y Literatura','LL-4',5,NULL,NULL),(39,'Ciencias Naturales','CN-4',5,NULL,NULL),(40,'Ciencias Sociales','CS-4',5,NULL,NULL),(41,'Educación Estética','EE-4',5,NULL,NULL),(42,'Educación Física','EF-4',5,NULL,NULL),(43,'Inglés','I-4O',5,NULL,NULL),(44,'Computación','C-4O',5,NULL,NULL),(45,'Formación Cristiana','FC-4O',5,NULL,NULL),(46,'Valores Humanos','VH-4O',5,NULL,NULL),(47,'Matemática','M-5',6,NULL,NULL),(48,'Lenguaje y Literatura','LL-5',6,NULL,NULL),(49,'Ciencias Naturales','CN-5',6,NULL,NULL),(50,'Ciencias Sociales','CS-5',6,NULL,NULL),(51,'Educación Estética','EE-5',6,NULL,NULL),(52,'Educación Física','EF-5',6,NULL,NULL),(53,'Inglés','I-5O',6,NULL,NULL),(54,'Computación','C-5O',6,NULL,NULL),(55,'Formación Cristiana','FC-5O',6,NULL,NULL),(56,'Valores Humanos','VH-5O',6,NULL,NULL),(57,'Matemática','M-6',7,NULL,NULL),(58,'Lenguaje y Literatura','LL-6',7,NULL,NULL),(59,'Ciencias Naturales','CN-6',7,NULL,NULL),(60,'Ciencias Sociales','CS-6',7,NULL,NULL),(61,'Educación Estética','EE-6',7,NULL,NULL),(62,'Educación Física','EF-6',7,NULL,NULL),(63,'Inglés','I-6O',7,NULL,NULL),(64,'Computación','C-6O',7,NULL,NULL),(65,'Formación Cristiana','FC-6O',7,NULL,NULL),(66,'Valores Humanos','VH-6O',7,NULL,NULL),(67,'Matemática','M-7',8,NULL,NULL),(68,'Lenguaje y Literatura','LL-7',8,NULL,NULL),(69,'Ciencias Naturales','CN-7',8,NULL,NULL),(70,'Ciencias Sociales','CS-7',8,NULL,NULL),(71,'Educación Estética','EE-7',8,NULL,NULL),(72,'Educación Física','EF-7',8,NULL,NULL),(73,'Inglés','I-7O',8,NULL,NULL),(74,'Computación','C-7O',8,NULL,NULL),(75,'Formación Cristiana','FC-7O',8,NULL,NULL),(76,'Valores Humanos','VH-7O',8,NULL,NULL);
/*!40000 ALTER TABLE `asignaturas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `asistencia_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asistencia_personal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_personal` int(10) unsigned NOT NULL,
  `id_fecha` int(10) unsigned NOT NULL,
  `entrada` time NOT NULL,
  `salida` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asistencia_personal_id_personal_foreign` (`id_personal`),
  KEY `asistencia_personal_id_fecha_foreign` (`id_fecha`),
  CONSTRAINT `asistencia_personal_id_fecha_foreign` FOREIGN KEY (`id_fecha`) REFERENCES `fechas_asistencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `asistencia_personal_id_personal_foreign` FOREIGN KEY (`id_personal`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `asistencia_personal` WRITE;
/*!40000 ALTER TABLE `asistencia_personal` DISABLE KEYS */;
INSERT INTO `asistencia_personal` VALUES (7,2,7,'06:40:07','12:15:12','2017-02-10 10:00:33','2017-02-10 10:00:33'),(8,2,8,'06:45:06','12:15:22','2017-02-10 10:00:33','2017-02-10 10:00:34'),(9,2,9,'06:45:07','12:15:09','2017-02-10 10:00:34','2017-02-10 10:00:34'),(10,2,10,'06:45:10','12:15:08','2017-02-10 10:00:35','2017-02-10 10:00:35'),(11,2,11,'06:45:08','12:15:12','2017-02-10 10:00:35','2017-02-10 10:00:36'),(12,2,12,'06:45:06','12:15:14','2017-02-10 10:00:36','2017-02-10 10:00:36');
/*!40000 ALTER TABLE `asistencia_personal` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `aulas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aulas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `aulas` WRITE;
/*!40000 ALTER TABLE `aulas` DISABLE KEYS */;
/*!40000 ALTER TABLE `aulas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bloques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bloques` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bloque` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `id_dia` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bloques_id_dia_foreign` (`id_dia`),
  CONSTRAINT `bloques_id_dia_foreign` FOREIGN KEY (`id_dia`) REFERENCES `dias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bloques` WRITE;
/*!40000 ALTER TABLE `bloques` DISABLE KEYS */;
INSERT INTO `bloques` VALUES (1,'7:00 - 7:20',1),(2,'7:00 - 7:20',2),(3,'7:00 - 7:20',3),(4,'7:00 - 7:20',4),(5,'7:00 - 7:20',5),(6,'7:20 - 8:00',1),(7,'7:20 - 8:00',2),(8,'7:20 - 8:00',3),(9,'7:20 - 8:00',4),(10,'7:20 - 8:00',5),(11,'8:00 - 8:40',1),(12,'8:00 - 8:40',2),(13,'8:00 - 8:40',3),(14,'8:00 - 8:40',4),(15,'8:00 - 8:40',5),(16,'8:40 - 9:20',1),(17,'8:40 - 9:20',2),(18,'8:40 - 9:20',3),(19,'8:40 - 9:20',4),(20,'8:40 - 9:20',5),(21,'9:20 - 9:40',1),(22,'9:20 - 9:40',2),(23,'9:20 - 9:40',3),(24,'9:20 - 9:40',4),(25,'9:20 - 9:40',5),(26,'9:40 - 10:20',1),(27,'9:40 - 10:20',2),(28,'9:40 - 10:20',3),(29,'9:40 - 10:20',4),(30,'9:40 - 10:20',5),(31,'10:20 - 11:00',1),(32,'10:20 - 11:00',2),(33,'10:20 - 11:00',3),(34,'10:20 - 11:00',4),(35,'10:20 - 11:00',5),(36,'11:00 - 11:40',1),(37,'11:00 - 11:40',2),(38,'11:00 - 11:40',3),(39,'11:00 - 11:40',4),(40,'11:00 - 11:40',5),(41,'11:40 - 12:20',1),(42,'11:40 - 12:20',2),(43,'11:40 - 12:20',3),(44,'11:40 - 12:20',4),(45,'11:40 - 12:20',5);
/*!40000 ALTER TABLE `bloques` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calificacion_parcial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calificacion_parcial` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parcial` int(10) unsigned NOT NULL,
  `id_asignatura` int(10) unsigned NOT NULL,
  `id_categoria` int(10) unsigned NOT NULL,
  `calificacion` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calificacion_parcial_id_parcial_foreign` (`id_parcial`),
  KEY `calificacion_parcial_id_asignatura_foreign` (`id_asignatura`),
  KEY `calificacion_parcial_id_categoria_foreign` (`id_categoria`),
  CONSTRAINT `calificacion_parcial_id_asignatura_foreign` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_parcial_id_categoria_foreign` FOREIGN KEY (`id_categoria`) REFERENCES `categorias_parcial` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_parcial_id_parcial_foreign` FOREIGN KEY (`id_parcial`) REFERENCES `parciales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calificacion_parcial` WRITE;
/*!40000 ALTER TABLE `calificacion_parcial` DISABLE KEYS */;
/*!40000 ALTER TABLE `calificacion_parcial` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calificacion_parcial_subtotal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calificacion_parcial_subtotal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_parcial` int(10) unsigned NOT NULL,
  `id_asignatura` int(10) unsigned NOT NULL,
  `avg_total` double NOT NULL,
  `id_equivalencia` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calificacion_parcial_subtotal_id_parcial_foreign` (`id_parcial`),
  KEY `calificacion_parcial_subtotal_id_asignatura_foreign` (`id_asignatura`),
  KEY `calificacion_parcial_subtotal_id_equivalencia_foreign` (`id_equivalencia`),
  CONSTRAINT `calificacion_parcial_subtotal_id_asignatura_foreign` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_parcial_subtotal_id_equivalencia_foreign` FOREIGN KEY (`id_equivalencia`) REFERENCES `equivalencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_parcial_subtotal_id_parcial_foreign` FOREIGN KEY (`id_parcial`) REFERENCES `parciales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calificacion_parcial_subtotal` WRITE;
/*!40000 ALTER TABLE `calificacion_parcial_subtotal` DISABLE KEYS */;
/*!40000 ALTER TABLE `calificacion_parcial_subtotal` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calificacion_quimestre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calificacion_quimestre` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_quimestrales` int(10) unsigned NOT NULL,
  `id_asignatura` int(10) unsigned NOT NULL,
  `avg_gp` double NOT NULL,
  `avg_gp80` double NOT NULL,
  `examen_q` double NOT NULL,
  `examen_q20` double NOT NULL,
  `avg_q_cuantitativa` double NOT NULL,
  `id_equivalencia` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calificacion_quimestre_id_quimestrales_foreign` (`id_quimestrales`),
  KEY `calificacion_quimestre_id_asignatura_foreign` (`id_asignatura`),
  KEY `calificacion_quimestre_id_equivalencia_foreign` (`id_equivalencia`),
  CONSTRAINT `calificacion_quimestre_id_asignatura_foreign` FOREIGN KEY (`id_asignatura`) REFERENCES `asignaturas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_quimestre_id_equivalencia_foreign` FOREIGN KEY (`id_equivalencia`) REFERENCES `equivalencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_quimestre_id_quimestrales_foreign` FOREIGN KEY (`id_quimestrales`) REFERENCES `quimestrales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calificacion_quimestre` WRITE;
/*!40000 ALTER TABLE `calificacion_quimestre` DISABLE KEYS */;
/*!40000 ALTER TABLE `calificacion_quimestre` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calificacion_recuperativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calificacion_recuperativos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `id_recuperativo` int(10) unsigned NOT NULL,
  `calificacion` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calificacion_recuperativos_id_estudiante_foreign` (`id_estudiante`),
  KEY `calificacion_recuperativos_id_periodo_foreign` (`id_periodo`),
  KEY `calificacion_recuperativos_id_recuperativo_foreign` (`id_recuperativo`),
  CONSTRAINT `calificacion_recuperativos_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_recuperativos_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `calificacion_recuperativos_id_recuperativo_foreign` FOREIGN KEY (`id_recuperativo`) REFERENCES `tipo_recuperativos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calificacion_recuperativos` WRITE;
/*!40000 ALTER TABLE `calificacion_recuperativos` DISABLE KEYS */;
/*!40000 ALTER TABLE `calificacion_recuperativos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cantidad_descuento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cantidad_descuento` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipoempleado` int(10) unsigned NOT NULL,
  `cantidad` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cantidad_descuento_id_tipoempleado_foreign` (`id_tipoempleado`),
  CONSTRAINT `cantidad_descuento_id_tipoempleado_foreign` FOREIGN KEY (`id_tipoempleado`) REFERENCES `tipo_empleado` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cantidad_descuento` WRITE;
/*!40000 ALTER TABLE `cantidad_descuento` DISABLE KEYS */;
INSERT INTO `cantidad_descuento` VALUES (1,1,0.6,NULL,NULL),(2,2,10,NULL,'2017-02-10 10:02:01'),(3,2,0.8,NULL,NULL);
/*!40000 ALTER TABLE `cantidad_descuento` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cargos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cargos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_area` int(10) unsigned NOT NULL,
  `id_tipo_empleado` int(10) unsigned NOT NULL,
  `nombre` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cargos_id_area_foreign` (`id_area`),
  KEY `cargos_id_tipo_empleado_foreign` (`id_tipo_empleado`),
  CONSTRAINT `cargos_id_area_foreign` FOREIGN KEY (`id_area`) REFERENCES `area_trabajos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cargos_id_tipo_empleado_foreign` FOREIGN KEY (`id_tipo_empleado`) REFERENCES `tipo_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cargos` WRITE;
/*!40000 ALTER TABLE `cargos` DISABLE KEYS */;
INSERT INTO `cargos` VALUES (1,1,1,'DIRECTOR(A)',NULL,NULL),(2,1,1,'COORDINADOR(A)',NULL,NULL),(3,1,2,'SECRETARIO(A)',NULL,NULL),(4,4,2,'DOCENTE DE PLANTA',NULL,NULL),(5,4,2,'DOCENTE ROTATIVO',NULL,NULL),(6,5,2,'DIRIGENTE DE CURSO',NULL,NULL),(7,8,3,'LIMPIEZA',NULL,NULL),(8,8,3,'MANTENIMIENTO',NULL,NULL),(9,8,3,'ELECTRICISTA',NULL,NULL),(10,8,3,'FONTANERO',NULL,NULL);
/*!40000 ALTER TABLE `cargos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorias_parcial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias_parcial` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categoria` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorias_parcial` WRITE;
/*!40000 ALTER TABLE `categorias_parcial` DISABLE KEYS */;
INSERT INTO `categorias_parcial` VALUES (1,'Deberes',NULL,NULL),(2,'Actividades Individuales',NULL,NULL),(3,'Actividades Grupales',NULL,NULL),(4,'Lecciones',NULL,NULL),(5,'Aporte',NULL,NULL);
/*!40000 ALTER TABLE `categorias_parcial` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `comportamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comportamiento` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `literal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `comportamiento` WRITE;
/*!40000 ALTER TABLE `comportamiento` DISABLE KEYS */;
INSERT INTO `comportamiento` VALUES (1,'A','Muy Satisfactorio',NULL,NULL),(2,'B','Satisfactorio',NULL,NULL),(3,'C','Poco Satisfactorio',NULL,NULL),(4,'D','Mejorable',NULL,NULL),(5,'E','Insatisfactorio',NULL,NULL);
/*!40000 ALTER TABLE `comportamiento` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cursos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `curso` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cursos_curso_unique` (`curso`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cursos` WRITE;
/*!40000 ALTER TABLE `cursos` DISABLE KEYS */;
INSERT INTO `cursos` VALUES (1,'Educación Inicial',NULL,NULL),(2,'1 ero',NULL,NULL),(3,'2 do',NULL,NULL),(4,'3 ero',NULL,NULL),(5,'4 to',NULL,NULL),(6,'5 to',NULL,NULL),(7,'6 to',NULL,NULL),(8,'7 mo',NULL,NULL);
/*!40000 ALTER TABLE `cursos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_generales_estudiante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_generales_estudiante` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_representante` int(10) unsigned NOT NULL,
  `foto` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `codigo_matricula` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellido_paterno` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `apellido_materno` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nombres` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nacionalidad_ced` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `fecha_registro` date NOT NULL,
  `genero` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `estado_actual` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_registro` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8_unicode_ci NOT NULL,
  `nacionalidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `provincia` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ciudad_natal` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `datos_generales_estudiante_codigo_matricula_unique` (`codigo_matricula`),
  KEY `datos_generales_estudiante_id_representante_foreign` (`id_representante`),
  CONSTRAINT `datos_generales_estudiante_id_representante_foreign` FOREIGN KEY (`id_representante`) REFERENCES `datos_representantes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_generales_estudiante` WRITE;
/*!40000 ALTER TABLE `datos_generales_estudiante` DISABLE KEYS */;
/*!40000 ALTER TABLE `datos_generales_estudiante` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_generales_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_generales_personal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `codigo_pesonal` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `apellido_paterno` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `apellido_materno` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nombres` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cedula` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `edad` int(11) NOT NULL,
  `edo_civil` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `genero` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  `estado_actual` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `tipo_registro` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `especialidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` text COLLATE utf8_unicode_ci NOT NULL,
  `telefono` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `clave` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `ingreso_notas` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `id_cargo` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `datos_generales_personal_codigo_pesonal_unique` (`codigo_pesonal`),
  UNIQUE KEY `datos_generales_personal_cedula_unique` (`cedula`),
  UNIQUE KEY `datos_generales_personal_correo_unique` (`correo`),
  KEY `datos_generales_personal_id_cargo_foreign` (`id_cargo`),
  CONSTRAINT `datos_generales_personal_id_cargo_foreign` FOREIGN KEY (`id_cargo`) REFERENCES `cargos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_generales_personal` WRITE;
/*!40000 ALTER TABLE `datos_generales_personal` DISABLE KEYS */;
INSERT INTO `datos_generales_personal` VALUES (1,'12421412','UGUETO','ESCOBAR','LUIS','24388425','1995-08-04','2010-01-01',21,'casado','M','Activo','1','INFORMÁTICA','asfasfas','04160408205','lui_su_gueto@hotmail.com','$2y$10$Ypp/sYYu','1',4,NULL,NULL),(2,'123456','CAMPOS','','ORIONED','20758169','1990-05-09','2010-01-01',32,'soltero','M','Activo','1','INFORMÁTICA','aqui','04262343358','en4pami@gmail.com','$2y$10$37E6xJ7z','1',5,NULL,NULL);
/*!40000 ALTER TABLE `datos_generales_personal` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_medicos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `grupo_sanguineo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `peso` double(10,2) NOT NULL,
  `altura` double(10,2) NOT NULL,
  `capacidad_especial` text COLLATE utf8_unicode_ci NOT NULL,
  `porcentaje_discapacidad` int(11) NOT NULL,
  `medicinas_contraindicadas` text COLLATE utf8_unicode_ci NOT NULL,
  `alergico_a` text COLLATE utf8_unicode_ci NOT NULL,
  `patologia` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `datos_medicos_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `datos_medicos_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_medicos` WRITE;
/*!40000 ALTER TABLE `datos_medicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `datos_medicos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_padres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_padres` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombres_pa` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `cedula_pa` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `foto_pa` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lugar_trabajo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `direccion_pa` text COLLATE utf8_unicode_ci NOT NULL,
  `telefono_pa` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `correo_pa` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `nacionalidad_pa` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nivel_educacion` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `datos_padres_correo_pa_unique` (`correo_pa`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_padres` WRITE;
/*!40000 ALTER TABLE `datos_padres` DISABLE KEYS */;
/*!40000 ALTER TABLE `datos_padres` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_representantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_representantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombres_re` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nacionalidad_ce` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `cedula_re` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `parentesco` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `nacionalidad_re` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `telefono_re` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `direccion_re` text COLLATE utf8_unicode_ci NOT NULL,
  `vive_con` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_representantes` WRITE;
/*!40000 ALTER TABLE `datos_representantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `datos_representantes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `datos_unidad_precedente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datos_unidad_precedente` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `curso` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `periodo` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `inst_precedente` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `term_primaria` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `datos_unidad_precedente_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `datos_unidad_precedente_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `datos_unidad_precedente` WRITE;
/*!40000 ALTER TABLE `datos_unidad_precedente` DISABLE KEYS */;
/*!40000 ALTER TABLE `datos_unidad_precedente` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `descuentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `descuentos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_tipo_empleado` int(10) unsigned NOT NULL,
  `descuento` double(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `descuentos_id_tipo_empleado_foreign` (`id_tipo_empleado`),
  CONSTRAINT `descuentos_id_tipo_empleado_foreign` FOREIGN KEY (`id_tipo_empleado`) REFERENCES `tipo_empleado` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `descuentos` WRITE;
/*!40000 ALTER TABLE `descuentos` DISABLE KEYS */;
/*!40000 ALTER TABLE `descuentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dia` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dias` WRITE;
/*!40000 ALTER TABLE `dias` DISABLE KEYS */;
INSERT INTO `dias` VALUES (1,'LUNES'),(2,'MARTES'),(3,'MIÉRCOLES'),(4,'JUEVES'),(5,'VIERNES');
/*!40000 ALTER TABLE `dias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `documentacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentacion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `codigo` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `a` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `entregado` date NOT NULL,
  `digitalizado` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documentacion_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `documentacion_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `documentacion` WRITE;
/*!40000 ALTER TABLE `documentacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentacion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `equivalencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equivalencias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `minimo` double NOT NULL,
  `maximo` double NOT NULL,
  `literales` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `equivalencias` WRITE;
/*!40000 ALTER TABLE `equivalencias` DISABLE KEYS */;
INSERT INTO `equivalencias` VALUES (1,9,10,'DAR','Domina el Aprendizaje Requerido',NULL,NULL),(2,7,8.99,'AAR','Alcanza el Aprendizaje Requerido',NULL,NULL),(3,4.01,6.99,'PAAR','Próximo al Aprendizaje Requerido',NULL,NULL),(4,1,4,'NAAR','No Alcanza el Aprendizaje Requerido',NULL,NULL);
/*!40000 ALTER TABLE `equivalencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facturacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturacion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `numero` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `total_pago` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `facturacion_numero_unique` (`numero`),
  KEY `facturacion_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `facturacion_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `facturacion` WRITE;
/*!40000 ALTER TABLE `facturacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturacion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facturas_rubros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturas_rubros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura` int(10) unsigned NOT NULL,
  `id_rubro` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `facturas_rubros_id_factura_foreign` (`id_factura`),
  KEY `facturas_rubros_id_rubro_foreign` (`id_rubro`),
  CONSTRAINT `facturas_rubros_id_factura_foreign` FOREIGN KEY (`id_factura`) REFERENCES `facturacion` (`id`) ON DELETE CASCADE,
  CONSTRAINT `facturas_rubros_id_rubro_foreign` FOREIGN KEY (`id_rubro`) REFERENCES `rubros` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `facturas_rubros` WRITE;
/*!40000 ALTER TABLE `facturas_rubros` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturas_rubros` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fechas_asistencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fechas_asistencias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fechas_asistencias_fecha_unique` (`fecha`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fechas_asistencias` WRITE;
/*!40000 ALTER TABLE `fechas_asistencias` DISABLE KEYS */;
INSERT INTO `fechas_asistencias` VALUES (7,'2017-01-20','2017-02-10 10:00:32','2017-02-10 10:00:32'),(8,'2017-02-21','2017-02-10 10:00:33','2017-02-10 10:00:33'),(9,'2017-01-22','2017-02-10 10:00:34','2017-02-10 10:00:34'),(10,'2017-01-23','2017-02-10 10:00:35','2017-02-10 10:00:35'),(11,'2017-01-24','2017-02-10 10:00:35','2017-02-10 10:00:35'),(12,'2017-01-25','2017-02-10 10:00:36','2017-02-10 10:00:36');
/*!40000 ALTER TABLE `fechas_asistencias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forma_pagos_realizados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forma_pagos_realizados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pagos` int(10) unsigned NOT NULL,
  `id_forma` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forma_pagos_realizados_id_pagos_foreign` (`id_pagos`),
  KEY `forma_pagos_realizados_id_forma_foreign` (`id_forma`),
  CONSTRAINT `forma_pagos_realizados_id_forma_foreign` FOREIGN KEY (`id_forma`) REFERENCES `formas_pagos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `forma_pagos_realizados_id_pagos_foreign` FOREIGN KEY (`id_pagos`) REFERENCES `pagos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forma_pagos_realizados` WRITE;
/*!40000 ALTER TABLE `forma_pagos_realizados` DISABLE KEYS */;
/*!40000 ALTER TABLE `forma_pagos_realizados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `forma_rubros_realizados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forma_rubros_realizados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_forma` int(10) unsigned NOT NULL,
  `id_rubro_realizado` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forma_rubros_realizados_id_forma_foreign` (`id_forma`),
  KEY `forma_rubros_realizados_id_rubro_realizado_foreign` (`id_rubro_realizado`),
  CONSTRAINT `forma_rubros_realizados_id_forma_foreign` FOREIGN KEY (`id_forma`) REFERENCES `formas_pagos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `forma_rubros_realizados_id_rubro_realizado_foreign` FOREIGN KEY (`id_rubro_realizado`) REFERENCES `rubros_realizados` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `forma_rubros_realizados` WRITE;
/*!40000 ALTER TABLE `forma_rubros_realizados` DISABLE KEYS */;
/*!40000 ALTER TABLE `forma_rubros_realizados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `formas_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `formas_pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `forma` enum('Efectivo','Cheque','Transferencia') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `formas_pagos` WRITE;
/*!40000 ALTER TABLE `formas_pagos` DISABLE KEYS */;
INSERT INTO `formas_pagos` VALUES (1,'Efectivo',NULL,NULL),(2,'Cheque',NULL,NULL),(3,'Transferencia',NULL,NULL);
/*!40000 ALTER TABLE `formas_pagos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `i_e_s_s`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `i_e_s_s` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `valor` double(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `i_e_s_s` WRITE;
/*!40000 ALTER TABLE `i_e_s_s` DISABLE KEYS */;
INSERT INTO `i_e_s_s` VALUES (1,'Patrono',12.40,NULL,NULL),(2,'Personal',9.40,NULL,NULL);
/*!40000 ALTER TABLE `i_e_s_s` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `informacion_academica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `informacion_academica` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_personal` int(10) unsigned NOT NULL,
  `primaria` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `secundaria` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `superior` varchar(55) COLLATE utf8_unicode_ci NOT NULL,
  `titulo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cursos` text COLLATE utf8_unicode_ci NOT NULL,
  `historial_laboral` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `informacion_academica_id_personal_foreign` (`id_personal`),
  CONSTRAINT `informacion_academica_id_personal_foreign` FOREIGN KEY (`id_personal`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `informacion_academica` WRITE;
/*!40000 ALTER TABLE `informacion_academica` DISABLE KEYS */;
INSERT INTO `informacion_academica` VALUES (1,1,'asfaf','asfasfas','asfasfasfas','asfasfas','asfasfas','asfasfas',NULL,NULL),(2,2,'asfaf','asfasfas','asfasfasfas','asfasfas','asfasfas','asfasfas',NULL,NULL);
/*!40000 ALTER TABLE `informacion_academica` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inscripciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inscripciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `id_curso` int(10) unsigned NOT NULL,
  `id_seccion` int(10) unsigned NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `repite` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `becado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inscripciones_id_estudiante_foreign` (`id_estudiante`),
  KEY `inscripciones_id_curso_foreign` (`id_curso`),
  KEY `inscripciones_id_seccion_foreign` (`id_seccion`),
  KEY `inscripciones_id_periodo_foreign` (`id_periodo`),
  CONSTRAINT `inscripciones_id_curso_foreign` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inscripciones_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inscripciones_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inscripciones_id_seccion_foreign` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inscripciones` WRITE;
/*!40000 ALTER TABLE `inscripciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `inscripciones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1),('2016_12_15_123527_create_roles_table',1),('2016_12_15_203437_create_datos_representantes_table',1),('2016_12_15_203438_create_datos_generales_estudiante_table',1),('2016_12_15_203451_create_datos_medicos_table',1),('2016_12_15_203501_create_novedades_table',1),('2016_12_15_203516_create_documentacion_table',1),('2016_12_15_203549_create_datos_padres_table',1),('2016_12_15_211448_create_datos_unidad_precedente_table',1),('2016_12_15_231045_create_area_trabajos_table',1),('2016_12_15_231223_create_tipo_empleado_table',1),('2016_12_15_231224_create_cargos_table',1),('2016_12_15_231225_create_datos_generales_personal_table',1),('2016_12_15_231422_create_informacion_academica_table',1),('2016_12_15_231458_create_remuneracion_table',1),('2016_12_16_035718_create_cursos_table',1),('2016_12_16_035929_create_asignaturas_table',1),('2016_12_16_052954_create_equivalencias_table',1),('2016_12_16_054049_create_comportamiento_table',1),('2016_12_16_060300_create_categorias_parcial_table',1),('2016_12_16_083353_create_nivelacion_table',1),('2016_12_17_021528_create_i_e_s_s_table',1),('2016_12_17_043434_create_periodos_table',1),('2016_12_17_052204_create_quimestres_table',1),('2016_12_17_052205_create_parciales_table',1),('2016_12_17_052206_create_calificacion_parcial_table',1),('2016_12_17_052207_create_calificacion_parcial_subtotal_table',1),('2016_12_17_052208_create_quimestrales_table',1),('2016_12_17_062542_create_calificacion_quimestre_table',1),('2016_12_17_094548_create_prestamos_table',1),('2016_12_17_095156_create_formas_pagos_table',1),('2016_12_17_095316_create_modalidads_table',1),('2016_12_17_095339_create_pagos_realizados_table',1),('2016_12_17_095612_create_pagos_table',1),('2016_12_17_095650_create_forma_pagos_realizados_table',1),('2016_12_18_104434_create_seccions_table',1),('2016_12_18_112813_create_aulas_table',1),('2016_12_18_173050_create_rubros_table',1),('2016_12_19_050739_create_dias_table',1),('2016_12_19_050740_create_bloques_table',1),('2016_12_19_051146_create_asignacion_bloques_table',1),('2016_12_19_051147_create_asignacion_table',1),('2016_12_19_051414_create_asignacion_dp_table',1),('2016_12_22_013907_create_inscripciones_table',1),('2016_12_22_055818_create_fechas_asistencias',1),('2016_12_22_063902_create_asistencia_personal_table',1),('2016_12_22_144033_create_padres_has_estudiantes_table',1),('2016_12_22_180103_create_retardo_asistencia_table',1),('2016_12_23_173953_create_facturacion_table',1),('2016_12_23_174336_create_facturas_rubros_table',1),('2016_12_23_174609_create_rubros_realizados_table',1),('2016_12_23_175114_create_forma_rubros_realizados_table',1),('2016_12_27_011631_create_morosos_table',1),('2017_01_15_140019_create_asignacioncoordinador_table',1),('2017_01_19_093107_create_tipo_recuperativos_table',1),('2017_01_19_093128_create_calificacion_recuperativos_table',1),('2017_02_03_091058_create_descuentos_table',1),('2017_02_03_142419_create_cantidad_descuento_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `modalidads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modalidads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `modalidad` enum('Exacto','Abono') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `modalidads` WRITE;
/*!40000 ALTER TABLE `modalidads` DISABLE KEYS */;
INSERT INTO `modalidads` VALUES (1,'Exacto',NULL,NULL),(2,'Abono',NULL,NULL);
/*!40000 ALTER TABLE `modalidads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `morosos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `morosos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura` int(10) unsigned NOT NULL,
  `id_estudiante` int(10) unsigned NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `morosos_id_factura_foreign` (`id_factura`),
  KEY `morosos_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `morosos_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE,
  CONSTRAINT `morosos_id_factura_foreign` FOREIGN KEY (`id_factura`) REFERENCES `facturacion` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `morosos` WRITE;
/*!40000 ALTER TABLE `morosos` DISABLE KEYS */;
/*!40000 ALTER TABLE `morosos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `nivelacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nivelacion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `recuperacion` double NOT NULL,
  `supletorio` double NOT NULL,
  `remedial` double NOT NULL,
  `gracia` double NOT NULL,
  `id_estudiante` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nivelacion_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `nivelacion_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `nivelacion` WRITE;
/*!40000 ALTER TABLE `nivelacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `nivelacion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `novedades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `novedades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `fecha` date NOT NULL,
  `detalles` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `novedades_id_estudiante_foreign` (`id_estudiante`),
  CONSTRAINT `novedades_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `novedades` WRITE;
/*!40000 ALTER TABLE `novedades` DISABLE KEYS */;
/*!40000 ALTER TABLE `novedades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `padres_has_estudiantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `padres_has_estudiantes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `id_padre` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `padres_has_estudiantes_id_estudiante_foreign` (`id_estudiante`),
  KEY `padres_has_estudiantes_id_padre_foreign` (`id_padre`),
  CONSTRAINT `padres_has_estudiantes_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE,
  CONSTRAINT `padres_has_estudiantes_id_padre_foreign` FOREIGN KEY (`id_padre`) REFERENCES `datos_padres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `padres_has_estudiantes` WRITE;
/*!40000 ALTER TABLE `padres_has_estudiantes` DISABLE KEYS */;
/*!40000 ALTER TABLE `padres_has_estudiantes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_personal` int(10) unsigned NOT NULL,
  `id_prestamo` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pagos_id_personal_foreign` (`id_personal`),
  KEY `pagos_id_prestamo_foreign` (`id_prestamo`),
  CONSTRAINT `pagos_id_personal_foreign` FOREIGN KEY (`id_personal`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pagos_id_prestamo_foreign` FOREIGN KEY (`id_prestamo`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pagos_realizados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos_realizados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `monto_pagado` double(10,2) NOT NULL,
  `monto_adeudado` double(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `id_prestamo` int(10) unsigned NOT NULL,
  `id_modalidad` int(10) unsigned NOT NULL,
  `id_personal` int(10) unsigned NOT NULL,
  `no_transferencia` bigint(20) NOT NULL,
  `no_cheque` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pagos_realizados_id_prestamo_foreign` (`id_prestamo`),
  CONSTRAINT `pagos_realizados_id_prestamo_foreign` FOREIGN KEY (`id_prestamo`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pagos_realizados` WRITE;
/*!40000 ALTER TABLE `pagos_realizados` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos_realizados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `parciales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parciales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `id_quimestre` int(10) unsigned NOT NULL,
  `id_comportamiento` int(10) unsigned NOT NULL,
  `faltas_j` int(11) NOT NULL,
  `faltas_i` int(11) NOT NULL,
  `atrasos_j` int(11) NOT NULL,
  `atrasos_i` int(11) NOT NULL,
  `observaciones` text COLLATE utf8_unicode_ci NOT NULL,
  `avg_aprovechamiento` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parciales_id_estudiante_foreign` (`id_estudiante`),
  KEY `parciales_id_quimestre_foreign` (`id_quimestre`),
  KEY `parciales_id_comportamiento_foreign` (`id_comportamiento`),
  CONSTRAINT `parciales_id_comportamiento_foreign` FOREIGN KEY (`id_comportamiento`) REFERENCES `comportamiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `parciales_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE,
  CONSTRAINT `parciales_id_quimestre_foreign` FOREIGN KEY (`id_quimestre`) REFERENCES `quimestres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `parciales` WRITE;
/*!40000 ALTER TABLE `parciales` DISABLE KEYS */;
/*!40000 ALTER TABLE `parciales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `periodos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `periodos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('activo','inactivo') COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `periodos_nombre_unique` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `periodos` WRITE;
/*!40000 ALTER TABLE `periodos` DISABLE KEYS */;
INSERT INTO `periodos` VALUES (1,'2005','inactivo',NULL,NULL),(2,'2006','inactivo',NULL,NULL),(3,'2007','inactivo',NULL,NULL),(4,'2008','inactivo',NULL,NULL),(5,'2009','inactivo',NULL,NULL),(6,'2010','inactivo',NULL,NULL),(7,'2011','inactivo',NULL,NULL),(8,'2012','inactivo',NULL,NULL),(9,'2013','inactivo',NULL,NULL),(10,'2014','inactivo',NULL,NULL),(11,'2015','inactivo',NULL,NULL),(12,'2016','inactivo',NULL,NULL),(13,'2017','activo',NULL,NULL),(14,'2018','inactivo',NULL,NULL),(15,'2019','inactivo',NULL,NULL),(16,'2020','inactivo',NULL,NULL),(17,'2021','inactivo',NULL,NULL),(18,'2022','inactivo',NULL,NULL),(19,'2023','inactivo',NULL,NULL),(20,'2024','inactivo',NULL,NULL),(21,'2025','inactivo',NULL,NULL),(22,'2026','inactivo',NULL,NULL),(23,'2027','inactivo',NULL,NULL),(24,'2028','inactivo',NULL,NULL),(25,'2029','inactivo',NULL,NULL),(26,'2030','inactivo',NULL,NULL),(27,'2031','inactivo',NULL,NULL),(28,'2032','inactivo',NULL,NULL),(29,'2033','inactivo',NULL,NULL),(30,'2034','inactivo',NULL,NULL);
/*!40000 ALTER TABLE `periodos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prestamos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_personal` int(10) unsigned NOT NULL,
  `tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `motivo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `monto` double(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestamos_id_personal_foreign` (`id_personal`),
  CONSTRAINT `prestamos_id_personal_foreign` FOREIGN KEY (`id_personal`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prestamos` WRITE;
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `quimestrales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quimestrales` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_estudiante` int(10) unsigned NOT NULL,
  `id_quimestre` int(10) unsigned NOT NULL,
  `total_faltas_j` int(11) NOT NULL,
  `total_faltas_i` int(11) NOT NULL,
  `total_atrasos_j` int(11) NOT NULL,
  `total_atrasos_i` int(11) NOT NULL,
  `sumatoria` double NOT NULL,
  `avg_aprovechamiento_q` double NOT NULL,
  `id_comportamiento` int(10) unsigned NOT NULL,
  `recomendaciones` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quimestrales_id_estudiante_foreign` (`id_estudiante`),
  KEY `quimestrales_id_quimestre_foreign` (`id_quimestre`),
  KEY `quimestrales_id_comportamiento_foreign` (`id_comportamiento`),
  CONSTRAINT `quimestrales_id_comportamiento_foreign` FOREIGN KEY (`id_comportamiento`) REFERENCES `comportamiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quimestrales_id_estudiante_foreign` FOREIGN KEY (`id_estudiante`) REFERENCES `datos_generales_estudiante` (`id`) ON DELETE CASCADE,
  CONSTRAINT `quimestrales_id_quimestre_foreign` FOREIGN KEY (`id_quimestre`) REFERENCES `quimestres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `quimestrales` WRITE;
/*!40000 ALTER TABLE `quimestrales` DISABLE KEYS */;
/*!40000 ALTER TABLE `quimestrales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `quimestres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quimestres` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `inicio` date NOT NULL,
  `fin` date NOT NULL,
  `numero` int(11) NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `quimestres_inicio_unique` (`inicio`),
  UNIQUE KEY `quimestres_fin_unique` (`fin`),
  KEY `quimestres_id_periodo_foreign` (`id_periodo`),
  CONSTRAINT `quimestres_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `quimestres` WRITE;
/*!40000 ALTER TABLE `quimestres` DISABLE KEYS */;
/*!40000 ALTER TABLE `quimestres` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `remuneracion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `remuneracion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_personal` int(10) unsigned NOT NULL,
  `sueldo_mens` double(10,2) NOT NULL,
  `descuento_iess` double(10,2) NOT NULL,
  `bono_responsabilidad` double(10,2) NOT NULL,
  `horas_extras` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `cuenta_bancaria` bigint(20) NOT NULL,
  `devolver_fondos` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `remuneracion_id_personal_foreign` (`id_personal`),
  CONSTRAINT `remuneracion_id_personal_foreign` FOREIGN KEY (`id_personal`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `remuneracion` WRITE;
/*!40000 ALTER TABLE `remuneracion` DISABLE KEYS */;
INSERT INTO `remuneracion` VALUES (1,1,1000.00,30.00,500.00,'Y',71264876124,'N',NULL,NULL),(2,2,1000.00,20.00,500.00,'Y',7129964876124,'N',NULL,NULL);
/*!40000 ALTER TABLE `remuneracion` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `retardo_asistencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retardo_asistencia` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_personal` int(10) unsigned NOT NULL,
  `id_fecha_asistencia` int(10) unsigned NOT NULL,
  `retardo` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `retardo_asistencia_id_fecha_asistencia_foreign` (`id_fecha_asistencia`),
  KEY `retardo_asistencia_id_personal_foreign` (`id_personal`),
  CONSTRAINT `retardo_asistencia_id_fecha_asistencia_foreign` FOREIGN KEY (`id_fecha_asistencia`) REFERENCES `fechas_asistencias` (`id`) ON DELETE CASCADE,
  CONSTRAINT `retardo_asistencia_id_personal_foreign` FOREIGN KEY (`id_personal`) REFERENCES `datos_generales_personal` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `retardo_asistencia` WRITE;
/*!40000 ALTER TABLE `retardo_asistencia` DISABLE KEYS */;
INSERT INTO `retardo_asistencia` VALUES (7,2,7,30,NULL,NULL),(8,2,8,35,NULL,NULL),(9,2,9,35,NULL,NULL),(10,2,10,35,NULL,NULL),(11,2,11,35,NULL,NULL),(12,2,12,35,NULL,NULL);
/*!40000 ALTER TABLE `retardo_asistencia` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','Administrador',NULL,NULL),(2,'Director','Director',NULL,NULL),(3,'Profesor','Profesor',NULL,NULL),(4,'Recurso Humano','Recurso Humano',NULL,NULL),(5,'DACE','DACE',NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rubros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rubros` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `monto` double(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `id_curso` int(10) unsigned NOT NULL,
  `id_periodo` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rubros_id_curso_foreign` (`id_curso`),
  KEY `rubros_id_periodo_foreign` (`id_periodo`),
  CONSTRAINT `rubros_id_curso_foreign` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rubros_id_periodo_foreign` FOREIGN KEY (`id_periodo`) REFERENCES `periodos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rubros` WRITE;
/*!40000 ALTER TABLE `rubros` DISABLE KEYS */;
/*!40000 ALTER TABLE `rubros` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `rubros_realizados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rubros_realizados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura_rubro` int(10) unsigned NOT NULL,
  `monto_pagado` double(10,2) NOT NULL,
  `monto_adeudado` double(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `id_modalidad` int(10) unsigned NOT NULL,
  `no_transferencia` bigint(20) NOT NULL,
  `no_cheque` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rubros_realizados_id_factura_rubro_foreign` (`id_factura_rubro`),
  KEY `rubros_realizados_id_modalidad_foreign` (`id_modalidad`),
  CONSTRAINT `rubros_realizados_id_factura_rubro_foreign` FOREIGN KEY (`id_factura_rubro`) REFERENCES `facturas_rubros` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rubros_realizados_id_modalidad_foreign` FOREIGN KEY (`id_modalidad`) REFERENCES `modalidads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `rubros_realizados` WRITE;
/*!40000 ALTER TABLE `rubros_realizados` DISABLE KEYS */;
/*!40000 ALTER TABLE `rubros_realizados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `secciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `secciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_curso` int(10) unsigned NOT NULL,
  `literal` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `capacidad` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `secciones_id_curso_foreign` (`id_curso`),
  CONSTRAINT `secciones_id_curso_foreign` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `secciones` WRITE;
/*!40000 ALTER TABLE `secciones` DISABLE KEYS */;
INSERT INTO `secciones` VALUES (1,1,'A',50,NULL,NULL),(2,2,'A',50,NULL,NULL),(3,3,'A',50,NULL,NULL),(4,4,'A',50,NULL,NULL),(5,5,'A',50,NULL,NULL),(6,6,'A',50,NULL,NULL),(7,7,'A',50,NULL,NULL),(8,8,'A',50,NULL,NULL),(9,1,'B',50,NULL,NULL),(10,2,'B',50,NULL,NULL),(11,3,'B',50,NULL,NULL),(12,4,'B',50,NULL,NULL),(13,5,'B',50,NULL,NULL),(14,6,'B',50,NULL,NULL),(15,7,'B',50,NULL,NULL),(16,8,'B',50,NULL,NULL),(17,1,'C',50,NULL,NULL),(18,2,'C',50,NULL,NULL),(19,3,'C',50,NULL,NULL),(20,4,'C',50,NULL,NULL),(21,5,'C',50,NULL,NULL),(22,6,'C',50,NULL,NULL),(23,7,'C',50,NULL,NULL),(24,8,'C',50,NULL,NULL);
/*!40000 ALTER TABLE `secciones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tipo_empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_empleado` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo_empleado` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tipo_empleado` WRITE;
/*!40000 ALTER TABLE `tipo_empleado` DISABLE KEYS */;
INSERT INTO `tipo_empleado` VALUES (1,'ADMINISTRATIVO',NULL,NULL),(2,'DOCENTE',NULL,NULL),(3,'OBRERO',NULL,NULL);
/*!40000 ALTER TABLE `tipo_empleado` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tipo_recuperativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_recuperativos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tipo_recuperativos` WRITE;
/*!40000 ALTER TABLE `tipo_recuperativos` DISABLE KEYS */;
INSERT INTO `tipo_recuperativos` VALUES (1,'RECUPERACIÓN',NULL,NULL),(2,'SUPLETORIO',NULL,NULL),(3,'REMEDIAL',NULL,NULL),(4,'GRACIA',NULL,NULL);
/*!40000 ALTER TABLE `tipo_recuperativos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roles_id` int(10) unsigned NOT NULL,
  `foto` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Luis','blink242@outlook.com','$2y$10$3K4hw/JWn8mvEG9QLKAFWuSoa/Z81Jjl0i8ClrvZ/kXBDxJKi9q/m',1,'',NULL,NULL,NULL),(2,'Jesus','mtr_1101@hotmail.com','$2y$10$mN6gne9591oA8Q92.rsQ.uvWgAeEynBUWIbwZpmEmZyRFl.7.glSm',1,'',NULL,NULL,NULL),(3,'Cesar','jcesarchg9@gmail.com','$2y$10$uY/ZFtcHAGtiCThYBDOaceP7wikuAWpDeoCLBCVBAjsGsGZO.TuAG',1,'',NULL,NULL,NULL),(4,'ADMIN DACE','dace@system.com','$2y$10$PLUlmtyhV4BuOpXVS3k.Qu1hd9VWR5jYz0SxS9N.IG/iZNa8vle.6',5,'','rksRc5Un78jQueAZljrxfKyOwOsWfBcbqAuWxDnZ','2017-02-10 09:47:15','2017-02-10 09:47:15'),(5,'LUIS ESCOBAR','lui_su_gueto@hotmail.com','$2y$10$MVgCeKtpV7f38EqVsPtobOEqbk/bA92VRjeXbuhlYiCteG4Xw/GO.',3,'',NULL,NULL,NULL),(6,'ORIONED CAMPOS','en4pami@gmail.com','$2y$10$qnJBOYoapawOlYmTn.f7eeWA9l3tQig9tvwKwcKhhFdok8iw81756',3,'',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

